# Claude Code skills-pakke — 20 skills (2026-07-11)

## Hva dette er
20 skills for Claude Code: oppskrifter agentene følger for research, bygging,
sangtekster, bilde-/videoprompts, planlegging, git, sikkerhet og kvalitet.

## Installasjon
Pakk ut `skills/`-mappen til `.claude/skills/` i prosjektet ditt
(eller `~/.claude/skills/` for å ha dem i alle prosjekter).
Claude Code plukker dem opp automatisk ved neste økt.

## Innhold
1. dyp-research — grundig research med kilder
2. github-speiding — finn og vurder GitHub-prosjekter
3. bygg-fra-repo — klon og få prosjekter til å kjøre
4. sangtekster — techno / norsk folkemusikk / black metal
5. musikk-prompts — Suno/Udio-prompts
6. bilde-prompts — gonzo-satire i sjablong-gatekunst-stil
7. video-prompts — Sora/Veo/Runway/Kling-scener
8. dagsplanlegging — realistiske dagsplaner
9. herde-orkestrering — koordinering av multiagenter
10. git-flyt — ryddige commits og push
11. prosjekt-oppsett — nye prosjekter på 5 minutter
12. kode-gjennomgang — feil, sikkerhet, kompleksitet
13. test-skriving — målrettede tester
14. feilsoking — systematisk debugging
15. dokumentasjon — README-er som blir lest
16. api-integrasjon — trygge API-koblinger
17. datainnsamling — lovlig og høflig datahenting
18. ide-brainstorm — divergér vilt, konvergér hardt
19. kvalitetskontroll — godkjenn eller returnér leveranser
20. leveranse-pakking — pakk og lever resultater

## Se også
Repoet `kreative-vibe-prosjekter` har hele Herden-oppsettet:
agenter i `.claude/agents/` og oppdragslister i `herden/oppdrag/`.
